#include <stdio.h>

#include "directory.h"
#include "utils.h"

struct directory_t *copy_directory(struct directory_t *source)
{
    /* TODO: add your implementation here */
    return NULL;
}
