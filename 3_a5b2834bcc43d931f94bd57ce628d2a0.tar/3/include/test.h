#pragma once

/* These are the tests for the implementation */
void run_test1();
void run_test2();
