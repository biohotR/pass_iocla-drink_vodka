#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "test.h"

void run_test2() {
    /* TODO: inspect the directory.o binary and find a method to get the flag */
}

int main(void) {
    run_test1();
    run_test2();
    return 0;
}